/*Brandon Snow hw05 .c file*/



#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "stack.h"

/*
typedef double stackElementT;

struct stackCDT {
    stackElementT *elements;
    int count;
    int size;
};*/
static stackADT stack;


void Displaystack();
void html_compare();

char* read_tag(FILE *fp);




int main(int nargs, char *argv[])
{
		FILE *fp;
    
		stack=NewStack();
		int i;
		int flag=0;
		char *htmlfile;
		printf("Here Init_html");
	/*open file*/
    fp = fopen(argv[1], "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Can't open!\n");
        exit(1);
    }
/*read everything into a file and push tag */
			for(i=0;i<=StackDepth(stack);i++)
				{
				htmlfile = read_tag(fp);
					if(!htmlfile)
							break;
				Push(stack,htmlfile);
				}


				html_compare(stack);

			
			
				Displaystack(stack);
				printf("\n");
				fclose(fp);
				FreeStack(stack);
				return (0);
}
	
	
/*this function will read in */
char* read_tag(FILE *fp)
{
		printf("\nHere Read_tag\n");
		int i=0;
		int ch;
		char *tmp;
		char *tag;
		int flag1=0, flag2=0;
	
	/*read tag in to string*/
					tmp = malloc(1024 * sizeof(char));
				while((ch = fgetc(fp)) != EOF )
								{
						
													if(ch == '<')
															{
																flag1 = 1;

															}
														else if(ch == ' ' && flag1 == 1)
															{
																	flag2 = 1;
															}
														 else if(ch == '>')
															{
																break;
															}
										
														if(flag1 == 1 && flag2 != 1)
																	tmp[i++]=ch;
	
															if(	tmp[i-1] == '<' )
																		i--;													
																			
								}
									
					if(ch == EOF)
								{
										return NULL;
								}
			tag = malloc(strlen(tmp) + 1);
				strcpy(tag,tmp);
				
				return(tag);	
					free(tmp);
}



/*return true if <title></title> match*/

void html_compare(stackADT stack)
{
/*i just dont know how to do this part at all*/
/* i cant get it to compare or pop right at all im having so many problems right here*/
/*i worked on this for days maybe i should just retake some classes*/
			int depth;
			int i,j;
			char *a;
			
		depth = StackDepth(stack);
			printf("STACK: ");
			for(i=depth;i>=0;i--)
			{
				
					
			}
			
				
};
/*print what i got*/
void Displaystack()
{
		int i, depth;
		depth = StackDepth(stack);
			printf("STACK: ");
			for(i=depth-1;i>=0;i--)
			{
				if(i<depth-1) printf(" ,");
					printf("%s",GetStackElement(stack,i));
			}
			printf("\n");

}

