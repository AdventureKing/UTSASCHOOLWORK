#include <stdio.h>
#include <stdlib.h>

/*update: apr 17th 6:27pm
  13 function(s)*/


/*functions that are done:
 **Insert/display/ListInOrder/ListPreOrder/FindNode/Display/Sum/Max/Min**
 */
/*What needs works:
 **Delete/NodeLevelOrder/count/maximumof/height**

/*Height of list*/
static int count=0;
typedef struct nodeT {
    int key;
    struct nodeT *left, *right;
} nodeT, *treeT;

int height(nodeT *t)
{
    if (t == NULL)
        return 0;
    else
        return (1 + maximumof(
                    height(t->left),
                    height(t->right)));
}
/*find integer*/

nodeT* FindNode(nodeT *t, int key)
{
    while(t !=NULL) 
    {
        if (key == t->key) 
        {
            printf("The number %d exists!!",key);
            return t;
        }
        if (key < t->key) {
            t = t->left;
        }
        else {
            t = t->right;
        }
    }
    printf("The number %d does not exist here!!", key);
    return (NULL);
}



/*display my tree*/
void DisplayTree(nodeT *t)
{
    if (t != NULL) {
        DisplayTree(t->left);
        printf("%d ",t->key);
        DisplayTree(t->right);
    }
}
/*Sum of tree*/

int add(nodeT *p)
{
  /*Testprintf("hit here"); wed 16th 6:13*/
    if (p == NULL)
        return 0;
    else
        return (p->key +
                add(p->left) +
                add(p->right));
}




/*list in order*/
void ListInOrder(nodeT *t)
{

    if(t == NULL)
        return;
    if(t->left ==NULL && t->right == NULL)
    {				
        printf("%d ",t->key);
        return;
    }
    ListInOrder(t->left);
    printf("%d ",t->key);
    ListInOrder(t->right);
}


/*post order of list before walk*/
void PostOrderWalk(nodeT *t)
{
    if(t == NULL)
    {
        return;
    }
    if(t->left ==NULL && t->right == NULL)
    {
        printf("%d ", t->key);
        return;
    }
    PostOrderWalk(t->left);
    PostOrderWalk(t->right);
    printf("%d ",t->key);

}


/*list order after walk*/
void PreOrderWalk(nodeT *t)
{
    if(t == NULL)
        return;
    if(t->left ==NULL && t->right == NULL)
    {
        printf("%d ", t->key);
        return;
    }

    printf("%d ",t->key);
    PreOrderWalk(t->left);
    PreOrderWalk(t->right);

}
void NodeLevelOrder(nodeT *t)
{
    if(t == NULL)
        return;

    if(t->left ==NULL && t->right == NULL)
    {
			printf("%d ", t->key);	
        return;
    }	
    
    NodeLevelOrder(t->left);
		NodeLevelOrder(t->right);
			printf("%d ", t->key);



}

/*Insert a node for me with a int key!!!!*/
void InsertNode(nodeT **tptr, int key)
{
    nodeT *tmp;
    tmp=*tptr;
    if (tmp == NULL) {
        tmp=(nodeT *)malloc(sizeof(nodeT));/*this fucking line :got it working with marcus tue april 16th*/
        tmp->key = key;
        tmp->left=NULL;
        tmp->right=NULL;
        *tptr=tmp;
        /*testprintf("Inserted node %d\n", tmp->key); tue 15th*/
        return;
    }
    else if (key < tmp->key) 
		{
        InsertNode(&tmp->left, key);
      /*printf("traversed left\n"); */
    } 
		else {
        InsertNode(&tmp->right, key);
        /*testprintf("traversed right\n"); tue 15th*/
	   		 }
}

void DeleteNode(nodeT **p, int key)
{/*
    nodeT *tmp;
    tmp = *p;
		while(tmp != NULL)
		{
			if(tmp->right->right != NULL)
				{
					tmp->;
				}
			if(tmp->key == key)
			{
				if(tmp->left == NULL && tmp->right == NULL)
					{
					free(tmp);
					}
				else if(tmp->left != NULL && tmp->right != NULL)
					{
						tmp
						tmp->left->right = tmp->right;
						free(tmp);
					}
				else if(
			}
		
		if(key < tmp->key && key != tmp->key)
			{
 				printf("traversed left\n"); 
					tmp= tmp->left;
					
			}
		else if(key >tmp->key && key != tmp->key)
			{
					tmp = tmp->right;
					
			}
		}*/
}

void Min(nodeT *t)
{
    /* testprintf("Hit here!\n"); wed 16th 6:34 */
    while(1)
    {
        if(t->left == NULL)
        {
            printf("%d",t->key);
            break;
        }
        else
            t=t->left;
    }
}
void Max(nodeT *t)
{
    /* testprintf("Hit here!\n"); wed 16th 6:38 */
    while(1)
    {
        if(t->right == NULL)
        {
            printf("%d",t->key);
            break;
        }
        else
            t=t->right;
    }
}
int Count(nodeT *t)
{		
     
 			int count=0;
			if(t == NULL)
			{
			
			return;
			}	
      if(t->left && t->right != NULL)
      {
       	count++;
				Count(t->left);
				Count(t->right);
      }
			else
			{
				Count(t->left);
				Count(t->right);
			}
  return(count);
          
}

void maximumof(nodeT *p, nodeT *t)
{
    /*find my lowest left or right*/
    if(t == NULL)
        return;
    if(t->left ==NULL && t->right == NULL)
    {
        printf("%d ", t->key);
        return;
    }

    NodeLevelOrder(t->left);
    NodeLevelOrder(t->right);
}
