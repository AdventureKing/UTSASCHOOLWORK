package Project1;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class PartView extends JFrame {
	
	private int gobalX = 400;
	private int gobalY = 300;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private DefaultListModel<String> listModel;
	private JTextField txtfldPartNumber;
	private JTextField txtfldPartName;
	private JLabel lblQuan;
	private JLabel lblVendor;
	private JTextField txtfldVendor;
	private JButton btnSave;
	private JTextField txtfldQuan;
	private InventoryView view;
	/**
	 * Create the frame.
	 */
	public PartView(final InventoryView view,final PartModel part, String buttonName) {
		this.view = view;
		//sets bounds for the part window
		setBounds(100, 100, gobalX, gobalY);
		contentPane = new JPanel();
		//observer creation
		this.addWindowListener(new WindowAdapter(){
			public void windowClosed(WindowEvent e){
				view.removePart(part.getPartName());
			}
		});
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//Part number label
		JLabel lblPartNumber = new JLabel("Part Number:");
		lblPartNumber.setBounds(30, 45, 110, 15);
		contentPane.add(lblPartNumber);
		
		//text field for the part number
		txtfldPartNumber = new JTextField(part.getPartNum());
		txtfldPartNumber.setBounds(200, 42, 150, 20);
		contentPane.add(txtfldPartNumber);
		
		//label for part name
		JLabel lblPartNm = new JLabel("Part Name:");
		lblPartNm.setBounds(30, 80, 115, 15);
		contentPane.add(lblPartNm);
		
		//text field for part name
		txtfldPartName = new JTextField(part.getPartName());
		txtfldPartName.setBounds(200, 77, 150, 20);
		contentPane.add(txtfldPartName);
		
		//label for vendor
		lblVendor = new JLabel("Vendor:");
		lblVendor.setBounds(30, 110, 110, 15);
		contentPane.add(lblVendor);
		
		//vendor text field
		txtfldVendor = new JTextField(part.getVendor());
		txtfldVendor.setBounds(200, 107, 150, 20);
		contentPane.add(txtfldVendor);
		
		//quantity label field
		lblQuan = new JLabel("Quantity:");
		lblQuan.setBounds(30, 140, 110, 15);
		contentPane.add(lblQuan);
		
		//quantity text field
		System.out.println("Test Quan2!!: " + part.getQuantity());
		txtfldQuan = new JTextField((part.getQuantity() + ""));
		txtfldQuan.setBounds(200, 138, 150, 20);
		contentPane.add(txtfldQuan);
		
		btnSave = new JButton(buttonName);
		btnSave.setBounds(138, 201, 90, 25);
		contentPane.add(btnSave);	
		if(buttonName.equals("Save"))
		{
			
			txtfldPartName.setEditable(false);
		}
	}
	
	//getters for the part view
	public JTextField getTxtfldPartNumber() { return txtfldPartNumber; }
	public JTextField getTxtfldPartName() { return txtfldPartName; }
	public JTextField getTxtfldVendor() { return txtfldVendor; }
	public JTextField getTxtfldQuan() {	return txtfldQuan; }
	
	//repaints the values of the part view to display proper info
	public void repaintTextFields(){
		this.txtfldQuan.repaint();
		this.txtfldVendor.repaint();
		this.txtfldPartNumber.repaint();
		this.txtfldPartName.repaint();
	}
	
	//registers the part window listeners
	public void registerListerners(PartController partController) {
		btnSave.addActionListener(partController);
	}
}
