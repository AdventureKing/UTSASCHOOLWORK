package Project1;

import java.awt.Component;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;


public class InventoryView extends JFrame {

	private int gobalX = 800;
	private int gobalY = 400;
	private InventoryModel inventoryModel;
	private ArrayList<String> currentOpenInventory = new ArrayList<String>();
	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnFile;
	private JTable partList;
	
	private DefaultTableModel tableModel;

	/**
	 * Create the frame.
	 */
	public InventoryView(InventoryModel inventoryModel) {
		
		System.out.println("wtf!");
		
		this.inventoryModel = inventoryModel;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, gobalX, gobalY);
		
		//menu bar for file and settings
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		//file on menu bar
		mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		//exit menu item
		JMenuItem mntmExit = new JMenuItem("Exit");
		mnFile.add(mntmExit);
		
		//creates new content Pane
		contentPane = new JPanel();
		contentPane.setLayout(null);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		//Creates the table and border
		TitledBorder titleWordList = BorderFactory.createTitledBorder("Inventory");
		tableModel = new DefaultTableModel(new Object[]{"Part Name","Part Number", "Quantity", " Vendor"},0);	
		partList = new JTable(tableModel){
			public boolean isCellEditable(int row, int column){return false;}
		};
		partList.getTableHeader().setReorderingAllowed(false);
		partList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		JScrollPane scroll = new JScrollPane(getPartList());
		scroll.setBounds(5, 5, 530, 315);
		scroll.setBorder(titleWordList);
		contentPane.add(scroll);
		
		//Add part Button for inventory  view
		JButton btnAddPart = new JButton("Add Part");
		btnAddPart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnAddPart.setBounds(550, 75, 220, 50);
		contentPane.add(btnAddPart);
		
		//Delete Part Button 
		JButton btnDeletePart = new JButton("Delete Part");
		btnDeletePart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnDeletePart.setBounds(550, 135, 220, 50);
		contentPane.add(btnDeletePart);
		
		//Edit part Button
		JButton btnViewPart = new JButton("Edit Part");
		btnViewPart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnViewPart.setBounds(550, 200, 220, 50);
		contentPane.add(btnViewPart);
		
		//populate list
		this.updateRow();
	}
	
	//Registers the listeners
	public void registerListerners(InventoryController inventoryController) {
		Component[] components = contentPane.getComponents();
		for (Component component : components) {
			if (component instanceof AbstractButton) {
				AbstractButton button = (AbstractButton) component;
				button.addActionListener(inventoryController);
			}
			components = mnFile.getMenuComponents();
			for(Component component1 : components){
				if(component1 instanceof AbstractButton){
					AbstractButton button = (AbstractButton) component1;
					button.addActionListener(inventoryController);
					
				}
			}
	   }
	}
	
	//grabs the current state of the model
	public void updateModel(InventoryModel model){
		this.inventoryModel = model;
	}

	//Returns the partlist from the view table
	public JTable getPartList() {
		return partList;
	}

	//changes the view table partlist
	public void setPartList(JTable partList) {
		this.partList = partList;
	}

	//updates the rows for our JTable
	public void updateRow() {
		partList.setModel(new DefaultTableModel(inventoryModel.getData(),inventoryModel.getColumnNames()));
	}

	//determines if multiple attempts at creating views of the same part
	public boolean isopen(String part) {
		if(currentOpenInventory.isEmpty())
			return false;
		for(String partName : currentOpenInventory)
		{
			if(partName.equals(part)){
				return true;
			}
		}
		return false;
	}

	//opens the view of the selected part
	public void addPartView(PartModel part) {
		currentOpenInventory.add(part.getPartName());
	}

	public void removePart(String partName) {
		// TODO Auto-generated method stub
		currentOpenInventory.remove(partName);
	}
}
