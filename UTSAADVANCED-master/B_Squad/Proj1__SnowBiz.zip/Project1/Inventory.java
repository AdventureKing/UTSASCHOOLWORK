package Project1;

import javax.swing.Timer;


public class Inventory {
	static Timer t = null;
	public static void main(String[] args) {		
		System.out.println("Im the shit");
		
		//instantiate the base MVC	
		InventoryModel model = new InventoryModel();
		InventoryView view = new InventoryView(model);
		InventoryController inventoryController = new InventoryController(view,model);

		//Register all listeners
		view.registerListerners(inventoryController);
		
		//Set base window attriubtes
		view.setResizable(true);
		view.setLocationRelativeTo(null);
		view.setVisible(true);
	}
}
