package Project1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * This class is the overall controller for the inventory system. It handles all
 * events that will trigger in this program.
 * 
 * @author snow
 *
 */
public class InventoryController implements ActionListener {
	private InventoryView view;
	private InventoryModel model;

	private PartModel partModel;
	private PartView partView;
	private PartController partController;
	private String buttonName;

	public InventoryController(InventoryView view, InventoryModel model) {
		this.view = view;
		this.model = model;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		String command = event.getActionCommand();
		if (command.equals("Exit")) {
			view.dispose();
			System.exit(0);
		} else if (command.equals("Add Part")) {
			view.repaint();

			buttonName = "Add";

			partModel = new PartModel(null, null, null, 0);
			partView = new PartView(view,partModel, buttonName);
			partController = new PartController(partModel, partView, model,
					view);

			partView.setVisible(true);
			partView.registerListerners(partController);
			partView.setDefaultCloseOperation(PartView.DISPOSE_ON_CLOSE);

		} else if (command.equals("Delete Part")) {

			if (model.inventory.isEmpty()) {
				view.repaint();
			} else {
				int row[] = view.getPartList().getSelectedRows();
				for (int i = 0; i < row.length; i++) {
					String partSelected = (view.getPartList().getValueAt(
							row[i], 0).toString());
					ArrayList<PartModel> inventory = model.getInventory();
					for (PartModel part : inventory) {
						if (part.getPartName().equals(partSelected)) {

							inventory.remove(part);
							model.setInventory(inventory);
							// view.removePart(row);
							break;
						}
					}
				}

			}
			view.updateRow();

		} else if (command.equals("Edit Part")) {
			if (model.inventory.isEmpty()) {
				view.repaint();
			} else {
				int row[] = view.getPartList().getSelectedRows();
				
					
					for (int i = 0; i < row.length; i++) {
						String partSelected = (view.getPartList().getValueAt(
								row[i], 0).toString());
						if (view.isopen(partSelected) == false) {
						
						ArrayList<PartModel> inventory = model.getInventory();
						for (PartModel part : inventory) {
							if (part.getPartName().equals(partSelected)) {
								buttonName = "Save";
								System.out.println("Test quan: "
										+ part.getQuantity());
								PartView partSelectedView = new PartView(view,part,
										buttonName);
								partController = new PartController(part,
										partSelectedView, model, view);
								
								partSelectedView.repaintTextFields();
								partSelectedView.setVisible(true);
								partSelectedView.registerListerners(partController);
								partSelectedView.setDefaultCloseOperation(PartView.DISPOSE_ON_CLOSE);
								view.addPartView(part);
							}							
						}
					}else{
						view.repaint();
					}
					
				}
				
			}
		}
	}

}
