package Project1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class PartController implements ActionListener {

	private PartView partView;
	private PartModel partModel;
	private InventoryView inventoryView;
	private InventoryModel inventoryModel;
	
	//instantiates the part window controller
	public PartController(PartModel partModel, PartView partView, InventoryModel inventoryModel, InventoryView inventoryView)
	{
		this.partView = partView;
		this.partModel = partModel;
		this.inventoryView = inventoryView;
		this.inventoryModel = inventoryModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		String command = event.getActionCommand();
		
		//determines what to do if add is pressed in part window
		if(command.equals("Add")){
			int flag;
			int quan = 0;
			if(partView.getTxtfldQuan().getText().length() == 0)
			{
				inventoryView.repaint();
				System.out.println("Error");
			}
			else
			 quan = Integer.parseInt(partView.getTxtfldQuan().getText());
			partModel = new PartModel(partView.getTxtfldPartNumber().getText(),partView.getTxtfldPartName().getText(),partView.getTxtfldVendor().getText(),quan);
			if((flag = inventoryModel.inventoryCheck(partModel)) > 0)
			{
				inventoryModel.addInventoryPart(partModel);
				partView.dispose();	
			}
			else
			{
			
				if(flag == -2){
					JOptionPane.showMessageDialog(null,"Enter a Quantity greater than 0.");
					System.out.println("Cant have quan below 0");
				}else if(flag == -4){
					JOptionPane.showMessageDialog(null,"Part with that name already exists.");
					System.out.println("Cant have parts with the same name");
				}else if(flag == -3){
					JOptionPane.showMessageDialog(null,"Please check your fields.");
					System.out.println("A vendor was not set.");
				}
			}
			System.out.println(flag);
			inventoryView.updateRow();
		//determines what to do if save is pressed in part window
		}else if(command.equals("Save")){
			partView.repaintTextFields();
			System.out.println("test");
				int quan = 0;
					int flag;
					System.out.println(partView.getTxtfldQuan().getText());
					if(partView.getTxtfldQuan().getText().length() == 0)
					{
						inventoryView.repaint();
						System.out.println("Error");
					}
					else
					 quan = Integer.parseInt(partView.getTxtfldQuan().getText());
					
					System.out.println(partModel.getPartName());
					
					PartModel partModel2 = new PartModel(partView.getTxtfldPartNumber().getText(),partView.getTxtfldPartName().getText(),partView.getTxtfldVendor().getText(),quan);
					System.out.println(partView.getTxtfldPartName().getText());
					
					
					
				if((flag = inventoryModel.inventoryCheck(partModel2)) > 0 || (flag = inventoryModel.inventoryCheck(partModel2)) == -4)
					{	
						inventoryView.removePart(partModel.getPartName());
						inventoryModel.updateInventoryPart(partModel2);
						inventoryView.updateRow();	
						partView.dispose();
					}else{
						if(flag == -2){
							JOptionPane.showMessageDialog(null,"Enter a Quantity greater than 0.");
							System.out.println("Cant have quan below 0");
						}
						else if(flag == -3){
							JOptionPane.showMessageDialog(null,"No vendor has been set.");
							System.out.println("A vendor was not set.");
						}
					} 
					
				System.out.println(flag);
			inventoryView.repaint();
		}
	}	
}
