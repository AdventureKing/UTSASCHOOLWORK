#include <stdio.h>

int main(){
int i;
int tot = 0;

for (i = 10; i > 0; i--) {
  printf("value:%d\n", tot);
    tot++;

}
printf("%d\n",tot);


}
