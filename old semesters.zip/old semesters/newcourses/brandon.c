#include <stdio.h>
#include <math.h>

int main(){
    printf("I am the man!!!\n");
    printf("%f",sqrt(4));
}
