#ifndef _randword_h
#define _randword_h

void InitDictionary(char *file);
char *ChooseRandomWord(void);
void free_all();

#endif
