ant26:~/courses/datastructures/class> ./xword bcd bd cy abcdef BCD BD cy CY

Your word [bcd] will now be checked against the word grid

Your word [bcd] was found in a row starting at[0][1]

Your word [bd] will now be checked against the word grid

Your word [bd] was found on a diagonal starting at[1][2]

Your word [cy] will now be checked against the word grid

Your word [cy] was found on a column starting at[1][1]

Your word [abcdef] will now be checked against the word grid

Your word [abcdef] was not found in the grid

Your word [BCD] will now be checked against the word grid

Your word [BCD] was found in a row starting at[0][1]

Your word [BD] will now be checked against the word grid

Your word [BD] was found on a diagonal starting at[1][2]

Your word [cy] will now be checked against the word grid

Your word [cy] was found on a column starting at[1][1]

Your word [CY] will now be checked against the word grid

Your word [CY] was found on a column starting at[1][1]

