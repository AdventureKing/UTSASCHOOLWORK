#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "ran.h"

int RandomNumber(int max, int min)
{
		
			int num;
			srand(time(NULL));
			num = rand() % (max-min+1);
			return (num);
}
