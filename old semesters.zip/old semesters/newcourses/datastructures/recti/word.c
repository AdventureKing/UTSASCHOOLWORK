/*Brandon Snow tfv024
 * this program will take a command line argument and search through a word
 * grid and find where those words appear in the grid. It will then print out 
 * where the word starts on the grid*/






#include <stdio.h>
#include <stdlib.h>

void check_r();
void checkc();
void check_d();

int main(int nargs , char *argv[])
{

    /*some kind of malloc for x*/
    
    char g[ROW][COL] = { {'a','b','c','d'},
                         {'d','c','b','a'},
                         {'x','y','z','d'}};

    /*fill up x with g*/
    for(i=0;i<row;i++)
    {
    for(j=0;j<column;j++)
    {
    
    }
}

 


/*here i need to take a filled x and check it against the given string from command line*/
void check_r(char z[],char x[][])
{
int i=0



}


void check_c()
{



}


void check_d()
{



}
