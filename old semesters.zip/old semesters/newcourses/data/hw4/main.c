#include <stdio.h>
#include <string.h>
#include	<stdlib.h>
#include <math.h>
#include <time.h>
#include "tree.h"


extern int ary[NUMBERS];
int main (int argc, char *argv[])
{
	int i;
	int y=0;
	//int count_final=0;
	int counter = 0;
	srand(time(NULL));

	for(y=0;y < 51; y++)
		{
		counter++;
		//printf("\nY:%d\n",y);
		generateRandomNumSequence();
		}
		printf("Level Difference   # of runs\n");
	/*	printf("Level Difference      # Runs\n");
		printf("0                         %d\n",count_0);
		printf("1                         %d\n",count_1);
		printf("2                         %d\n",count_2);
		printf("3                         %d\n",count_3);
		printf("4                         %d\n",count_4);
		printf("5                         %d\n",count_5);
		printf("7                         %d\n",count_6);
		printf("6                         %d\n",count_7);
		printf("8                         %d\n",count_8);
		printf("9                         %d\n",count_9);
		printf("10                        %d\n",count_10);
		printf("11                        %d\n",count_11);
		printf("12                        %d\n",count_12);
		printf("13                        %d\n",count_13);
		printf("14                        %d\n",count_14);
		printf("15                        %d\n",count_15);
		//count_final = count_0 + count_1+ count_2 + count_3 + count_4 + count_5 + count_6 + count_7 + count_8 + count_9 + count_10 + count_11 + count_12 + count_13 + count_14 + count_15;
		//printf("addition of all counts needs to be 50: %d\n",count_final);
		//printf("counter:%d\n",counter);*/
		for(i = 0; i < 100;i++)
		{
			if(ary[i] != 0)
					{
					printf("%9d %12d\n", i , ary[i]);
					}	
		}
		printf("\n");
	
	
	return 0;
}
