/*
node struct definition
and functional prototypes
*/
typedef struct node {
	char url[255];
} node;

void printNode(node * n);