#define STACKSIZE 10
#define FALSE 0
#define TRUE 1

node * stack;
/*
add variables as needed to keep track of stack top, # elements, capacity, etc. 
minimum is stack top or # elements
*/
//need to know where top is
int top;
node * growStack();
void initStack();
int full();
int empty();
int push(node * val);
node * pop();
int size();
