#include <stdio.h>
#include <stdlib.h>
#include "node.h"

/*
Node-specific functions go in here like printing, creating, and deleting nodes
*/

void printNode(node * n) {
	//TODO: implement this
	printf("URL: %s\n",n->url);
}
