/*hw 01:Brandon Snow tfv024
part 1.Write an ADT specification for the data structure: student
Values are id (integer)
, name (string)
, age (integer)
, gpa (float)


Problem 1:
abstract typedef<int id,int age,float gpa,char name[255]> studentCDT
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct studentCDT{
int id;
int age;
float gpa;
char name[255];
}studentCDT;

studentCDT *list;

studentCDT *fill_id_name(int id, char name[255]);
studentCDT *fill_age(int age);
studentCDT *fill_gpa(float gpa);
void printList(int listCount);

int main(int nargs, char *argv[])
{
	FILE *infp;
	int listCount=0;
	int i=0;
	int id;
	int age;
	float gpa;
	char name[255];
/*check you have a file on command line*/
	printf("CS 2123 Assignment 1 written by Brandon Snow\n");
	if(nargs != 2)
	{
		printf("No datafile was inputted on command line!\n");
		return(EXIT_FAILURE);
	}

	/*open file*/

	infp = fopen(argv[1],"r");
/*check if data is in data file*/

	if(infp == NULL)
	{
		printf("Error opening file please try again\n");
			return(EXIT_FAILURE);
	}


/*read data file into pointer that points to the structs that are being filled*/

		while(!feof(infp)) {
		fscanf(infp, "%d\n", &id);
		fscanf(infp, "%[^\n]", name);
		fscanf(infp, "%d\n", &age);
		fscanf(infp, "%f\n", &gpa);
		listCount++;
	}

		printf("# of records: %d\n", listCount);

		/*malloc for number of structs*/
		fclose(infp);
		list = (studentCDT *) malloc(sizeof(studentCDT) * listCount);



		infp = fopen(argv[1],"r");	
	
	while(!feof(infp))
	{
			fscanf(infp, "%d\n", &id);
			fscanf(infp, "%[^\n]", name);
			fscanf(infp, "%d\n", &age);
			fscanf(infp, "%f\n", &gpa);
			studentCDT *temp = NULL;
			studentCDT *temp1 = NULL;
			studentCDT *temp2 = NULL;
		/*check id and name*/
				if(id>0)
				{
						temp=fill_id_name(id,name);
				}
	/* check age*/
				if(age > 0)
				{
						temp1=fill_age(age);
				}
	/*cheack gpa*/
				if(gpa >=0 && gpa<= 4.0)
				{
						temp2=fill_gpa(gpa);
				}
/*put temp into listp[i]*/
			(list + i)->id = (temp)->id;
			
			strcpy((list + i)->name,temp->name);
			
			(list + i)->gpa = (temp2)->gpa;
			(list + i)->age = (temp1)->age;
			
			free(temp);
			free(temp2);
			free(temp1);
			
			i++;
	}
		
		printList(listCount);
 		printf("The total amount of students is:%d\n",listCount);
	return (0);
}
/*passed the check so fill name and id*/
studentCDT *fill_id_name(int id, char name[255])
{
			
		studentCDT *ret=(studentCDT *)malloc(sizeof(studentCDT));
		ret->id=id;
		strcpy(ret->name,name);
		
		return(ret);
}
/*passed the check so fill name and id*/
studentCDT *fill_age(int age)
{
			
		studentCDT *ret=(studentCDT *)malloc(sizeof(studentCDT));
		ret->age=age;
		
		return(ret);
}
/*passed the check so fill name and id*/
studentCDT *fill_gpa(float gpa)
{
			
		studentCDT *ret=(studentCDT *)malloc(sizeof(studentCDT));
		ret->gpa=gpa;
		return(ret);
}
/*print stuff for me*/
void printList(int listCount)
{
	
		int i;
	printf("list:\n");
	for(i = 0; i < listCount; i++) {
		studentCDT *p = list + i;
		printf("student: %d\n id: %d\n name:%s\n age:%d\n gpa:%f\n", (i + 1), p->id, p->name,p->age,p->gpa);
	}
}

/*


float avg_gpa()
{

};

float avg_age()
{

}*/
